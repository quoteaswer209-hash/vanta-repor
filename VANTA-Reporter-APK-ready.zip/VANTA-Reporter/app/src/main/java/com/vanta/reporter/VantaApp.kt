package com.vanta.reporter

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun VantaApp() {
    MaterialTheme {
        Surface(modifier = Modifier) {
            Text(text = "Welcome to VANTA Reporter")
        }
    }
}
