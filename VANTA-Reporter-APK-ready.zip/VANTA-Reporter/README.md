# VANTA Reporter

A starter Android application scaffold using Kotlin and Jetpack Compose.

## Build APK with GitHub Actions

1. Create a new GitHub repository and upload the contents of this folder (the files inside `VANTA-Reporter`, not the outer folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and run it with **Run workflow**, or push to `main` / `master`.
4. When the run finishes successfully, open the run and download the **VANTA-Reporter-APK** artifact.
5. Extract the downloaded ZIP; the installable debug APK is `app-debug.apk`.

## Build locally

With Gradle and Android SDK (API 35) installed, run:

```bash
gradle :app:assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
